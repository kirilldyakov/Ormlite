package com.example.user.graph_test;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.LinearLayout;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.helper.DateAsXAxisLabelFormatter;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class MainActivity extends AppCompatActivity {
    private GraphView graphView;
    private LinearLayout graphLayout;

    private DataPoint[] data = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        graphView = new GraphView(this);
        graphLayout = (LinearLayout) findViewById(R.id.GraphLayout);
        graphLayout.addView(graphView);
        graphView.getViewport().setScrollable(true);
        graphView.getViewport().setScalable(true);

        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE, -5);
        Date d1 = calendar.getTime();
        calendar.add(Calendar.DATE, 1);
        Date d2 = calendar.getTime();
        calendar.add(Calendar.DATE, 1);
        Date d3 = calendar.getTime();
        Date d4 = new Date(System.currentTimeMillis());

        DataPoint[] data = new DataPoint[4];
        data[0]= new DataPoint(d1, 1);
        data[1]= new DataPoint(d2, 5);
        data[2]= new DataPoint(d3, 3);
        data[3]= new DataPoint(d4, 6);
    ;
        LineGraphSeries<DataPoint> series = new LineGraphSeries<DataPoint>(data);

        graphView.addSeries(series);
        //graphView.getGridLabelRenderer().setLabelFormatter(new DateAsXAxisLabelFormatter(this));

        graphView.getGridLabelRenderer().setLabelFormatter(
                new DateAsXAxisLabelFormatter(getApplicationContext(),new SimpleDateFormat("ddMMyy h:MM:ss")));

        graphView.getGridLabelRenderer().setNumHorizontalLabels(3); // only 4 because

        // set manual x bounds to have nice steps
        graphView.getViewport().setMinX(d1.getTime());
        graphView.getViewport().setMaxX(d3.getTime());
        graphView.getViewport().setXAxisBoundsManual(true);

// as we use dates as labels, the human rounding to nice readable numbers
// is not nessecary
        graphView.getGridLabelRenderer().setHumanRounding(false);
    }
}
